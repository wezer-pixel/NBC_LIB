package tz.co.nbc.wso2.custommediators;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.synapse.MessageContext;
import org.apache.synapse.mediators.AbstractMediator;

import java.util.Base64;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.ByteArrayInputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;

import javax.jms.*;
import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.ibm.msg.client.jms.JmsFactoryFactory;
import com.ibm.msg.client.wmq.WMQConstants;

public class NBCIBMMQMediator extends AbstractMediator {
	
	private String username;
    private String password;
	private String operation;
    private String host;
    private int port;
    private String channel;
    private String queueManager;
    private String requestQueue;
    private String responseQueue;
    private String errorQueue;
    private String sslCipherSuite;
    private String certificatesInBase64;
    private long responseQueueTimeout;

    private static final Log log = LogFactory.getLog(NBCIBMMQMediator.class);

    @Override
    public boolean mediate(MessageContext context) {
        String responseMessage = null;
        String statusDescription = null;
        String statusCode = null;

        try {
            JmsConnectionFactory connectionFactory = createJMSConnectionFactory();
            setJMSProperties(connectionFactory, host, port, channel, queueManager, certificatesInBase64, sslCipherSuite);

            if ("request".equalsIgnoreCase(operation)) {
            	// Get first element of the soap body
            	String payload = context.getEnvelope().getBody().getFirstElement().toString(); 
                sendFccRequest(connectionFactory, payload, requestQueue, context);
            } else if ("response".equalsIgnoreCase(operation)) {
                getFccResponse(connectionFactory, errorQueue, responseQueueTimeout, context);
            } else if ("failed".equalsIgnoreCase(operation)) {
                getFccResponse(connectionFactory, errorQueue, responseQueueTimeout, context);
            }
        } catch (Exception e) {
            responseMessage = "Error occurred while interacting with IBM MQ:  " + e.getMessage();
            statusDescription = "Failure";
            statusCode = "500";
            log.info("Error occurred while interacting with IBM MQ: ", e);
            setResponseProperties(responseMessage, statusDescription, statusCode, context);
        }

        return true;
    }

    // Create a connection factory for IBM MQ
    private static JmsConnectionFactory createJMSConnectionFactory() throws JMSException {
        JmsFactoryFactory factoryFactory = JmsFactoryFactory.getInstance(WMQConstants.WMQ_PROVIDER);
        return factoryFactory.createConnectionFactory();
    }

    // Set properties for the connection factory
    private static void setJMSProperties(JmsConnectionFactory connectionFactory, String host, int port, String channel, String queueManager, String certificatesInBase64, String sslCipherSuite) throws Exception {
    	System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");
    	//System.setProperty("https.protocols", "TLSv1.2");

    	// Get certificates
    	// Decode the Base64 string
        byte[] decodedBytes = Base64.getDecoder().decode(certificatesInBase64);
        // Convert decoded bytes to a String
        String certificates = new String(decodedBytes);
        
        // Create a CertificateFactory
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        // Split the certificate chain string by each certificate
        String[] certs = certificates.split("(?=-----BEGIN CERTIFICATE-----)");
        
        // Create a KeyStore
        KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
        trustStore.load(null, null); // Initialize an empty KeyStore
        
        // Add each certificate in the chain
        for (int i = 0; i < certs.length; i++) {
            Certificate cert = cf.generateCertificate(new ByteArrayInputStream(certs[i].getBytes()));
            trustStore.setCertificateEntry("cert" + i, cert);
        }
        
        // Create a TrustManager from the KeyStore
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(trustStore);
        
        // Set up the SSLContext
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(), null);
        
        connectionFactory.setStringProperty(WMQConstants.WMQ_HOST_NAME, host);
        connectionFactory.setIntProperty(WMQConstants.WMQ_PORT, port);
        connectionFactory.setStringProperty(WMQConstants.WMQ_CHANNEL, channel);
        connectionFactory.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
        connectionFactory.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, queueManager);
        
        // Set the cipher suite
        connectionFactory.setStringProperty(WMQConstants.WMQ_SSL_CIPHER_SUITE, sslCipherSuite);
        //connectionFactory.setStringProperty(WMQConstants.WMQ_SSL_PEER_NAME, "CN=localhost");
        
        // Use the SSLContext for the connection
        SSLContext.setDefault(sslContext);
        
    }

    // // Set properties for the connection factory
    // private static void setJMSProperties(JmsConnectionFactory connectionFactory, String host, int port, String channel, String queueManager, String username, String password, String certificatesInBase64, String sslCipherSuite) throws Exception {
    // 	System.setProperty("com.ibm.mq.cfg.useIBMCipherMappings", "false");
    // 	//System.setProperty("https.protocols", "TLSv1.2");

    // 	// Get certificates
    // 	// Decode the Base64 string
    //     byte[] decodedBytes = Base64.getDecoder().decode(certificatesInBase64);
    //     // Convert decoded bytes to a String
    //     String certificates = new String(decodedBytes);
        
    //     // Create a CertificateFactory
    //     CertificateFactory cf = CertificateFactory.getInstance("X.509");
    //     // Split the certificate chain string by each certificate
    //     String[] certs = certificates.split("(?=-----BEGIN CERTIFICATE-----)");
        
    //     // Create a KeyStore
    //     KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
    //     trustStore.load(null, null); // Initialize an empty KeyStore
        
    //     // Add each certificate in the chain
    //     for (int i = 0; i < certs.length; i++) {
    //         Certificate cert = cf.generateCertificate(new ByteArrayInputStream(certs[i].getBytes()));
    //         trustStore.setCertificateEntry("cert" + i, cert);
    //     }
        
    //     // Create a TrustManager from the KeyStore
    //     TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
    //     tmf.init(trustStore);
        
    //     // Set up the SSLContext
    //     SSLContext sslContext = SSLContext.getInstance("TLS");
    //     sslContext.init(null, tmf.getTrustManagers(), null);
        
    //     connectionFactory.setStringProperty(WMQConstants.WMQ_HOST_NAME, host);
    //     connectionFactory.setIntProperty(WMQConstants.WMQ_PORT, port);
    //     connectionFactory.setStringProperty(WMQConstants.WMQ_CHANNEL, channel);
    //     connectionFactory.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
    //     connectionFactory.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, queueManager);
        
    //     // Set the cipher suite
    //     connectionFactory.setStringProperty(WMQConstants.WMQ_SSL_CIPHER_SUITE, sslCipherSuite);
    //     //connectionFactory.setStringProperty(WMQConstants.WMQ_SSL_PEER_NAME, "CN=localhost");
        
    //     // Add username and password authentication
    //     if(username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
    //     	connectionFactory.setStringProperty(WMQConstants.USERID, username); // Set username
    //         connectionFactory.setStringProperty(WMQConstants.PASSWORD, password); // Set password
    //         connectionFactory.setBooleanProperty(WMQConstants.USER_AUTHENTICATION_MQCSP, true); // Enable user authentication
    //     }
        
    //     // Use the SSLContext for the connection
    //     SSLContext.setDefault(sslContext);
        
    // }

    // Send a request to the queue
    private static void sendFccRequest(JmsConnectionFactory connectionFactory, String request, String queue, MessageContext context) {
        Connection connection = null;
        Session session = null;
        String responseMessage = null;
        String statusDescription = null;
        String statusCode = null;

        try {
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            Destination destination = session.createQueue(queue);
            MessageProducer producer = session.createProducer(destination);

            TextMessage message = session.createTextMessage(request);
            producer.send(message);
            
            responseMessage = "Message successfully sent to the queue: " + queue;
            statusDescription = "Success";
            statusCode = "201";
            log.info("Send request success: " + responseMessage);
        } catch (JMSException e) {
        	// Set failure response
        	responseMessage = "Error while sending message to the queue: " + e.getMessage();
            statusDescription = "Failure";
            statusCode = "500";
            log.info("Send request failure: ", e);
        } finally {
        	closeSession(session);
        	closeConnection(connection);
        }

        setResponseProperties(responseMessage, statusDescription, statusCode, context);
    }

    // Retrieve a response from the queue
    private static void getFccResponse(JmsConnectionFactory connectionFactory, String queue, long timeout, MessageContext context) {
        Connection connection = null;
        Session session = null;
        String responseMessage = null;
        String statusDescription = null;
        String statusCode = null;

        try {
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            Destination destination = session.createQueue(queue);
            MessageConsumer consumer = session.createConsumer(destination);

            connection.start(); // Start the connection to enable message delivery
            Message message = consumer.receive(timeout);

            if (message instanceof TextMessage) {
            	String receivedTxt = ((TextMessage) message).getText().replace("<?xml version=\"1.0\"?>", "");
            	receivedTxt = receivedTxt.replace("<!DOCTYPE FCCFT SYSTEM \"./FCCFT.DTD\">", "");
                receivedTxt = receivedTxt.replace("<FCCFT>", "");
                receivedTxt = receivedTxt.replace("</FCCFT>", "");
                responseMessage = receivedTxt;
                statusDescription = "Success";
                statusCode = "200";
                log.info("Get fcc response successfull: (" + responseMessage + ")");
            } else {
                // Set failure response
                responseMessage = "Received message is not a text message";
                statusDescription = "Failure";
                statusCode = "500";
            }
        } catch (JMSException e) {    
            // Set failure response
            responseMessage = "Error while get fcc response message to the queue: " + e.getMessage();
            statusDescription = "Failure";
            statusCode = "500";
            log.info("Get fcc response failure: ", e);
        } finally {
        	closeSession(session);
        	closeConnection(connection);
        }
        
        setResponseProperties(responseMessage, statusDescription, statusCode, context);
    }

    // Set response properties
    private static void setResponseProperties(String responseMessage, String statusDescription, String statusCode, MessageContext context) {
        context.setProperty("statusCode", statusCode);
        context.setProperty("statusDescription", statusDescription);
        context.setProperty("responseMessage", responseMessage);
    }

    // Utility method to close a JMS Session
    private static void closeSession(Session session) {
        if (session != null) {
            try {
                session.close();
            } catch (JMSException e) {
                log.error("Error closing JMS session: " + e.getMessage(), e);
            }
        }
    }

    // Utility method to close a JMS Connection
    private static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (JMSException e) {
                log.error("Error closing JMS connection: " + e.getMessage(), e);
            }
        }
    }
    
 // Getter and Setter for operation
    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    // Getter and Setter for host
    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    // Getter and Setter for port
    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    // Getter and Setter for channel
    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    // Getter and Setter for queueManager
    public String getQueueManager() {
        return queueManager;
    }

    public void setQueueManager(String queueManager) {
        this.queueManager = queueManager;
    }

    // Getter and Setter for requestQueue
    public String getRequestQueue() {
        return requestQueue;
    }

    public void setRequestQueue(String requestQueue) {
        this.requestQueue = requestQueue;
    }

    // Getter and Setter for responseQueue
    public String getResponseQueue() {
        return responseQueue;
    }

    public void setResponseQueue(String responseQueue) {
        this.responseQueue = responseQueue;
    }

    // Getter and Setter for errorQueue
    public String getErrorQueue() {
        return errorQueue;
    }

    public void setErrorQueue(String errorQueue) {
        this.errorQueue = errorQueue;
    }

    // Getter and Setter for responseQueueTimeout
    public long getResponseQueueTimeout() {
        return responseQueueTimeout;
    }

    public void setResponseQueueTimeout(long responseQueueTimeout) {
        this.responseQueueTimeout = responseQueueTimeout;
    }
    
    // Getter and Setter for username
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    // Getter and Setter for password
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    // Getter and Setter for sslCipherSuite
    public String getSslCipherSuite() {
        return sslCipherSuite;
    }

    public void setSslCipherSuite(String sslCipherSuite) {
        this.sslCipherSuite = sslCipherSuite;
    }
    
    // Getter and Setter for certificatesInBase64
    public String getCertificatesInBase64() {
        return certificatesInBase64;
    }

    public void setCertificatesInBase64(String certificatesInBase64) {
        this.certificatesInBase64 = certificatesInBase64;
    }

}
